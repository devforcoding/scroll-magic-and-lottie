gsap.registerPlugin(ScrollTrigger);


var heroTimeline = gsap.timeline({
    scrollTrigger: {
        trigger: ".hero",
        start: "top top",
        end: "bottom top",
        scrub: true,
    },
});


heroTimeline
    .to(".line1", { y: -120, duration: 0.6 })
    .to(".line2", { y: -120, duration: 0.9 }, "-=0.4");

// Анимация банок
var cansTimeline = gsap.timeline({
    scrollTrigger: {
        trigger: ".hero",
        start: "top top",
        end: "bottom top",
        scrub: true,
    },
});

cansTimeline.to("#can1 img, #can3 img", { scale: 0, y: -250, duration: 0.5, ease: "power1.out" });

var pinCan2Timeline = gsap.timeline({
    scrollTrigger: {
        trigger: ".hero",
        start: "top top",
        end: "bottom top",
        scrub: true,
        pin: "#can2",
        pinSpacing: false,
    },
});

pinCan2Timeline.to("#can2 img", { y: -170, ease: "power1.out" });


var moveCan2Timeline = gsap.timeline({
    scrollTrigger: {
        trigger: ".products",
        start: "top center",
        end: "bottom center",
        scrub: true,
    },
});

moveCan2Timeline.to("#can2 img", {
    x: () => document.querySelector(".main-can").getBoundingClientRect().left - document.querySelector("#can2").getBoundingClientRect().left,
    y: () => document.querySelector(".main-can").getBoundingClientRect().top - document.querySelector("#can2").getBoundingClientRect().top,
    duration: 0.8,
    ease: "power1.out",
});


gsap.to(".product-content", {
    scrollTrigger: {
        trigger: ".products",
        start: "top 75%",
        end: "bottom 25%",
        scrub: true,
    },
    opacity: 1,
    y: 0,
    duration: 1,
    ease: "power1.out",
});
