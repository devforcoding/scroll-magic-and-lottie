// Initialize ScrollMagic controller
var controller = new ScrollMagic.Controller();

var newscene  = new ScrollMagic.Scene();
console.log(newscene);

// Create a GSAP timeline for the hero text animations
var heroTimeline = gsap.timeline();

// Animate the first line of text moving up faster
heroTimeline
    .to('.line1', { y: -120, duration: 0.4 })
    .to('.line2', { y: -120, duration: 0.4,  }, '-=0.3');

// Animate the cans
var cansTimeline = gsap.timeline();

var can2Timeline = gsap.timeline();


// Animate cans 1 and 3 to scale down and move up
cansTimeline.to('#can1 img, #can3 img', { opacity: 0, y: -200, duration: 0.1, ease: 'power1.out' });

can2Timeline.to('#can2 img', {  y: -100,  ease: 'power1.out'  });

// Animate can 2 to move up and scale up



// Create ScrollMagic scenes
new ScrollMagic.Scene({
    triggerElement: '.hero',
    triggerHook: 0,
    duration: '50%' // Duration of the scene
})
    .setTween(heroTimeline)
    .addTo(controller);

new ScrollMagic.Scene({
    triggerElement: '.hero',
    triggerHook: 0,
    duration: '20%'
})
    .setTween(cansTimeline)
    .addTo(controller);


new ScrollMagic.Scene({
    triggerElement: '.hero',
    triggerHook: 0,
    duration: '50%'
})
    .setTween(can2Timeline)
    .addTo(controller);


// Pin the second can until it reaches the product section
new ScrollMagic.Scene({
    triggerElement: '.empty-section img',
    triggerHook: 0,
    duration: function () {
        return document.querySelector('.products').offsetTop - window.innerHeight;
    }
})
    .setPin('#can2', { pushFollowers: false })
    .addTo(controller);

// Move and unpin the second can in the product section
new ScrollMagic.Scene({
    triggerElement: '.products',
    triggerHook: 0,
    duration: '50%'
})
    .setTween(gsap.to('#can2 img', {
        x: () => document.querySelector('.main-can').getBoundingClientRect().left - document.querySelector('#can2').getBoundingClientRect().left,
        y: () => document.querySelector('.main-can').getBoundingClientRect().top - document.querySelector('#can2').getBoundingClientRect().top,
        duration: 0.8,
        ease: 'power1.out'
    }))
    .addTo(controller);

// Animate line height in .empty-section
new ScrollMagic.Scene({
    triggerElement: '.empty-section',
    triggerHook: 0,
    duration: '50%'
})
    .setTween(gsap.to('.empty-section img', {
        height: '200px', // New height of the line
        duration: 0.8,
        ease: 'power1.out'
    }))
    .addTo(controller);

// Fade in and move product-content in .products
new ScrollMagic.Scene({
    triggerElement: '.products',
    triggerHook: 0.5,
    duration: '50%'
})
    .setTween(gsap.to('.product-content', {
        opacity: 1,
        y: 0,
        duration: 1,
        ease: 'power1.out'
    }))
    .addTo(controller);
